CREATE DATABASE  IF NOT EXISTS `TesteTCC` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `TesteTCC`;
-- MySQL dump 10.13  Distrib 5.7.30, for Linux (i686)
--
-- Host: localhost    Database: TesteTCC
-- ------------------------------------------------------
-- Server version	5.7.30-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tblCliente`
--

DROP TABLE IF EXISTS `tblCliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblCliente` (
  `cli_cpf` bigint(11) NOT NULL,
  `cli_nome` varchar(255) NOT NULL,
  `cli_cep` int(8) NOT NULL,
  `cli_endereco` varchar(255) NOT NULL,
  `cli_numero` varchar(5) NOT NULL,
  `cli_bairro` varchar(45) NOT NULL,
  `cli_cidade` varchar(45) NOT NULL,
  `cli_estado` varchar(45) NOT NULL,
  `cli_email` varchar(45) NOT NULL,
  `cli_telefone` varchar(10) DEFAULT NULL,
  `cli_celular` varchar(11) DEFAULT NULL,
  `cli_senha` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`cli_cpf`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblCliente`
--

LOCK TABLES `tblCliente` WRITE;
/*!40000 ALTER TABLE `tblCliente` DISABLE KEYS */;
INSERT INTO `tblCliente` VALUES (12345678909,'Renata Silva',12519520,'Rua Francisco Rodrigues Montemor Filho','455','Jardim do Vale II','Guaratinguetá','SP','renata@gmail.com','','','0cd221b2243c77a42270da0e3d2d3e71bffb3a0a'),(32285016808,'renata cibele dos santos domingos',12515070,'Rua Francisco Santos Reis','752','Pedregulho','Guaratinguetá','SP','r.cibele.santos@bol.com.br','1231268788','12 98172358','2828cf5a769fe3c9ef5442726df55e2e15a0649b'),(61780286520,'Ingrid',12513460,'Rua Maria Cecília Monteiro dos Santos','45','Residencial Village Santana','Guaratinguetá','SP','ingrid@gmail.com','1231259090','','9d2f6fc4626693eadb5cfd625699091d69e9b0ad'),(88888888888,'Mikael Felipe',12507270,'Rua Edgar Alvim Pinto','696','Jardim Santa Luzia','Guaratinguetá','SP','mikael.felipe@gmail.com','','','276ebef9565d1ed418d15cab7ff671d8e6ac3512');
/*!40000 ALTER TABLE `tblCliente` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-07-24 13:59:12

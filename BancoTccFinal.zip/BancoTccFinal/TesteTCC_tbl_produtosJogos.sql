CREATE DATABASE  IF NOT EXISTS `TesteTCC` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `TesteTCC`;
-- MySQL dump 10.13  Distrib 5.7.30, for Linux (i686)
--
-- Host: localhost    Database: TesteTCC
-- ------------------------------------------------------
-- Server version	5.7.30-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tbl_produtosJogos`
--

DROP TABLE IF EXISTS `tbl_produtosJogos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_produtosJogos` (
  `pro_codigo` int(11) NOT NULL AUTO_INCREMENT,
  `pro_titulo` varchar(45) NOT NULL,
  `pro_categoria` int(10) DEFAULT NULL,
  `pro_fornecedor` bigint(14) DEFAULT NULL,
  `pro_classificacao` int(10) DEFAULT NULL,
  `pro_anoLancamento` year(4) NOT NULL,
  `pro_descricao` varchar(255) NOT NULL,
  `pro_sinopse` text NOT NULL,
  `pro_foto` varchar(255) DEFAULT NULL,
  `pro_preco` decimal(10,2) NOT NULL,
  `pro_status` tinyint(1) NOT NULL,
  PRIMARY KEY (`pro_codigo`),
  KEY `pro_categoria_idx` (`pro_categoria`),
  KEY `pro_classificacao_idx` (`pro_classificacao`),
  KEY `pro_fornecedor_idx` (`pro_fornecedor`),
  CONSTRAINT `pro_categoria` FOREIGN KEY (`pro_categoria`) REFERENCES `tbl_categoriaJogos` (`cat_codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `pro_classificacao` FOREIGN KEY (`pro_classificacao`) REFERENCES `tbl_classificacao` (`cla_codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `pro_fornecedor` FOREIGN KEY (`pro_fornecedor`) REFERENCES `tbl_fornecedor` (`for_cnpj`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_produtosJogos`
--

LOCK TABLES `tbl_produtosJogos` WRITE;
/*!40000 ALTER TABLE `tbl_produtosJogos` DISABLE KEYS */;
INSERT INTO `tbl_produtosJogos` VALUES (1,'Mario Bross',4,12100000000001,1,2002,'Jogo Mario','Jogo Mario','mario.jpg',30.00,1),(2,'The Sims Pets 2',1,12100000000001,3,2010,'','','thesims.jpeg',25.00,1),(3,'Tomb Raider',3,12100000000001,3,2020,'','','tbr.jpeg',27.00,1),(4,'GTA V',3,12100000000001,3,2019,'','GTA V','',35.00,1),(5,'TesteIntegridade',3,12100000000001,2,2020,'teste de integridade terça 14:31','teste de integridade terça 14:31','',20.00,1);
/*!40000 ALTER TABLE `tbl_produtosJogos` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-07-24 13:59:13

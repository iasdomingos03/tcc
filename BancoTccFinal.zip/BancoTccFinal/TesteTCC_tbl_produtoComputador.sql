CREATE DATABASE  IF NOT EXISTS `TesteTCC` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `TesteTCC`;
-- MySQL dump 10.13  Distrib 5.7.30, for Linux (i686)
--
-- Host: localhost    Database: TesteTCC
-- ------------------------------------------------------
-- Server version	5.7.30-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tbl_produtoComputador`
--

DROP TABLE IF EXISTS `tbl_produtoComputador`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_produtoComputador` (
  `com_codigo` int(11) NOT NULL AUTO_INCREMENT,
  `com_nome` varchar(45) NOT NULL,
  `com_descricao` varchar(45) NOT NULL,
  `com_marca` int(11) NOT NULL,
  `com_modelo` int(11) NOT NULL,
  `com_foto` varchar(255) NOT NULL,
  `com_arquitetura` varchar(45) NOT NULL,
  `com_preco` decimal(10,2) NOT NULL,
  `com_status` tinyint(1) NOT NULL,
  PRIMARY KEY (`com_codigo`),
  KEY `com_modelo_idx` (`com_modelo`),
  KEY `fk_tbl_produtoComputador_tbl_marca11_idx` (`com_marca`),
  CONSTRAINT `com_marca` FOREIGN KEY (`com_marca`) REFERENCES `tbl_marca1` (`mar_codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `com_modelo` FOREIGN KEY (`com_modelo`) REFERENCES `tbl_modelo` (`mod_codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_produtoComputador`
--

LOCK TABLES `tbl_produtoComputador` WRITE;
/*!40000 ALTER TABLE `tbl_produtoComputador` DISABLE KEYS */;
INSERT INTO `tbl_produtoComputador` VALUES (1,'Computador Positivo','Computador Positivo',3,1,'pc1.jpeg','x86',2100.00,1),(2,'Computador Intel','Computador Intel  Tela 14 Polegadas',2,3,'pc11.jpeg','X64',1600.00,1),(3,'Computador Positivo 17 polegadas','Computador Positivo 17 polegadas',3,3,'pc3.jpeg','x86',2100.00,1),(4,'Computador Positivo 17 polegadas','Computador Positivo 17 polegadas',3,3,'pc31.jpeg','x86',2100.00,1);
/*!40000 ALTER TABLE `tbl_produtoComputador` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-07-24 13:59:11
